//
//  ReminderService.swift
//  Havenly
//
//  Created by Clayton kingsbury on 8/21/18.
//  Copyright © 2018 Benjamin Walter. All rights reserved.
//

import Foundation
class ReminderService{
//    var stored: StoreReminder = StoreReminder()
//    var fetcher: FetchReminder = FetchReminder()
//    func store(note: Note)->Any{
//        var ret: Any = stored.store(note: note)
//        userModel.user.addReminder(rem: note)
//        return ret
//    }
//    func fetch(){
//        fetcher.fetch()
//    }
}
