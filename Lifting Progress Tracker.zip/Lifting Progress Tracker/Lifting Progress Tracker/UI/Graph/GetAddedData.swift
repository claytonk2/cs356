//
//  GetAddedData.swift
//  Havenly
//
//  Created by Clayton kingsbury on 9/18/18.
//  Copyright © 2018 Benjamin Walter. All rights reserved.
//

import Foundation
class GetAddedData{
//    var getter: GetPastHealth = GetPastHealth()
//    var getRecent: RecentHealthGet = RecentHealthGet()
//    func get(type: String){
//        if (type == GraphSettings.settings.getTop()){
//            GraphSettings.settings.getData(top: true, unitString: type)
//        }
//        if (type == GraphSettings.settings.getBottom()){
//            GraphSettings.settings.getData(top: false, unitString: type)
//        }
//        self.getRecentData( unitString: type)//getRecent.
//    }
    
    
//    func getRecentData(unitString: String){
//
//
//        if (unitString == "Blood Glucose") {
//            getRecent.getBG()//topSample = userModel.user.getBloodGlucose() as! [HKSample]
//
//        }//,"Blood Pressure","Calories","Carbs","Heart Rate","Medication"
//        else if ("Calories" == unitString){
//            getRecent.getCals()//topSample = userModel.user.getCalories() as! [HKSample] // dont have this info stored?
//
//        }
//        else if ("Steps" == unitString){
//            getRecent.getSteps()//topSample = userModel.user.getCalories() as! [HKSample] // dont have this info stored?
//
//        }
//        else if ("Blood Pressure" == unitString){
//            getRecent.getBP()//topSample = userModel.user.bloodPressure as! [HKSample] // dont have this info stored?
//
//
//        }
//        else if ("Carbs" == unitString){
//            getRecent.getCarbs()//topSample = userModel.user.getCarbs() as! [HKSample] // dont have this info stored?
//
//        }
//        else if ("Heart Rate" == unitString){
//            getRecent.getHR()//topSample = userModel.user.getHeartRate() as! [HKSample]
//        }
//        else if ("Medication" == unitString){}
//        
//    }
}
