//
//  FABmenuViewExtention.swift
//  Startup_App
//
//  Created by Clayton Kingsbury on 7/24/18.
//  Copyright © 2018 Clayton kingsbury. All rights reserved.
//

import UIKit

extension UIView {

    func FABmenuView() {
        
        
    }

}
